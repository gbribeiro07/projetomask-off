const modal1 = document.querySelector('.modal1');
const blur = document.querySelector('.blur');
const botao = document.querySelectorAll('.button');
const titulo1 = document.querySelector('.título_modal');
const titulo1p = document.querySelector('.título_modalp');
const text1 = document.querySelector('#texto');
const text1p = document.querySelector('#textop');
const titulo2 = document.querySelector('.título_modal');
const titulo2p = document.querySelector('.título_modalp');
const text2 = document.querySelector('#texto');
const text2p = document.querySelector('#textop');
const titulo3 = document.querySelector('.título_modal');
const titulo3p = document.querySelector('.título_modalp');
const text3 = document.querySelector('#texto');
const text3p = document.querySelector('#textop');
const titulo4 = document.querySelector('.título_modal');
const titulo4p = document.querySelector('.título_modalp');
const text4 = document.querySelector('#texto');
const text4p = document.querySelector('#textop');
const titulo5 = document.querySelector('.título_modal');
const titulo5p = document.querySelector('.título_modalp');
const text5 = document.querySelector('#texto');
const text5p = document.querySelector('#textop');
const titulo6 = document.querySelector('.título_modal');
const titulo6p = document.querySelector('.título_modalp');
const text6 = document.querySelector('#texto');
const text6p = document.querySelector('#textop');
const titulo7 = document.querySelector('.título_modal');
const titulo7p = document.querySelector('.título_modalp');
const text7 = document.querySelector('#texto');
const text7p = document.querySelector('#textop');
const titulo8 = document.querySelector('.título_modal');
const titulo8p = document.querySelector('.título_modalp');
const text8 = document.querySelector('#texto');
const text8p = document.querySelector('#textop');
const titulo9 = document.querySelector('.título_modal');
const titulo9p = document.querySelector('.título_modalp');
const text9 = document.querySelector('#texto');
const text9p = document.querySelector('#textop');
const titulo10 = document.querySelector('.título_modal');
const titulo10p = document.querySelector('.título_modalp');
const text10 = document.querySelector('#texto');
const text10p = document.querySelector('#textop');
const seta = document.querySelector('.seta');
const conto = document.querySelector('.dialogo');
const xis = document.querySelector('#xis');
const xis1 = document.querySelector('#xis1');
const audio = document.querySelectorAll('#audio_icon');


xis1.addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'hidden'
    blur.style.visibility = 'hidden'
})

botao[0].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo1.textContent = "Within"
    text1.textContent = "Preposition: inside (something).   Adverb: inside; indoors."
    titulo1p.textContent = "Dentro"
    text1p.textContent = "Advérbio: interior;interiormente; adentro."

    audio.mouse
})

botao[1].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo2.textContent = "Overwise"
    text2.textContent = "Adjective: excessively or unusually wise."
    titulo2p.textContent = "Excessivamente"
    text2p.textContent = "Advérbio: em demasia;de modo excessivo; sem moderação."
    
})
botao[2].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo3.textContent = "Improve"
    text3.textContent = "Verb: make or become better."
    titulo3p.textContent = "Melhorar"
    text3p.textContent = "Verbo: aperfeiçoar;produzir ou adquirir melhoria; mudar algo, alguém ou a si mesmo para um estado melhor."
    
})
botao[3].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo4.textContent = "Nor"
    text4.textContent = "Adjective: used before the second or further of two or more alternatives (the first being introduced by a negative such as “neither” or “not”) to indicate that they are each untrue or each do not happen; used to introduce a further negative statement."
    titulo4p.textContent = "Nem"
    text4p.textContent = "Conjunção: serve para ligar palavras e orações negativas. Advérbio: exprime negação."
    
})
botao[4].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo5.textContent = "Growth"
    text5.textContent = "Noun: the process of increasing."
    titulo5p.textContent = "Crescimento"
    text5p.textContent = "Substantivo masculino: multiplicação ou aumento em dimensão;desenvolvimento, progresso, evolução."
    
})
botao[5].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo6.textContent = "Recognizable"
    text6.textContent = "Adjective: able to be recognized or identified from previous encounters or knowledge."
    titulo6p.textContent = "Reconhecível"
    text6p.textContent = "Adjetivo de dois gêneros: passível de ser reconhecido; que se pode reconhecer facilmente."
    
})
botao[6].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo7.textContent = "Although"
    text7.textContent = "Conjunction: in spite of the fact that; even though."
    titulo7p.textContent = "Embora"
    text7p.textContent = "Advérbio: exprime ideia de retirada. Conjunção concessiva: apesar de, enquanto, mesmo que."
    
})
botao[7].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo8.textContent = "Reborn"
    text8.textContent = "Adjective: brought back to life or activity. Having experienced a complete spiritual change."
    titulo8p.textContent = "Renascido"
    text8p.textContent = "Adjetivo: renovar-se; rejuvenecer. Nascer de novo."
    
})
botao[8].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo9.textContent = "Magnesium"
    text9.textContent = "Noun: the chemical element of atomic number 12, a silver-white metal of the alkaline earth series. It is used to make strong lightweight alloys, especially for the aerospace industry, and is also used in flashbulbs and pyrotechnics because it burns with a brilliant white flame."
    titulo9p.textContent = "Magnésio"
    text9p.textContent = "Substantivo masculino: elemento químico (símbolo: Mg), de número atómico 12, metal branco como a prata, muito leve, que arde ao ar com uma chama deslumbrante. "
    
})
botao[9].addEventListener('click', (e) =>{
    e.preventDefault();

    modal1.style.visibility = 'visible'
    blur.style.visibility = 'visible'
    titulo10.textContent = "Apigenin"
    text10.textContent = "Noun: a yellowish crystalline compound C15H10O5 occurring usually as glycosides (such as apiin) in various plants; 4, 5,7-trihydroxy-flavone."
    titulo10p.textContent = "Apigenina"
    text10p.textContent = "Substantivo masculino: ingrediente de medicamentos fitoterápicos indicados para a cicatrização de feridas na boca e de suplementos alimentares."
    
})
seta.addEventListener('click', (e) =>{
    e.preventDefault();

    conto.style.visibility = 'visible'
})
xis.addEventListener('click', (e) =>{
    e.preventDefault();

    conto.style.visibility = 'hidden'
})

